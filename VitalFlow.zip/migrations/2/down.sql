
DROP TABLE achievements;
DROP TABLE daily_challenges;
DROP TABLE streak_tracking;
