
-- Table for tracking user achievements
CREATE TABLE achievements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL, -- 'badge', 'streak', 'challenge'
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  icon TEXT NOT NULL,
  requirement_value INTEGER NOT NULL, -- 7 for "7 day streak", 2000 for "2000ml daily"
  requirement_type TEXT NOT NULL, -- 'streak_days', 'daily_ml', 'weekly_ml'
  earned_at TIMESTAMP,
  is_earned BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for tracking daily challenges
CREATE TABLE daily_challenges (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date DATE NOT NULL UNIQUE,
  challenge_type TEXT NOT NULL, -- 'morning_cups', 'total_ml', 'hourly_sips'
  challenge_text TEXT NOT NULL,
  target_value INTEGER NOT NULL,
  current_progress INTEGER DEFAULT 0,
  is_completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for tracking streaks
CREATE TABLE streak_tracking (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  current_streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  last_goal_date DATE,
  goal_daily_ml INTEGER DEFAULT 2000, -- 2 liters default goal
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default achievements
INSERT INTO achievements (type, name, description, icon, requirement_value, requirement_type) VALUES
('badge', 'Hydration Hero', 'Drink 2 liters for 7 consecutive days', '🏆', 7, 'streak_days'),
('badge', 'Water Warrior', 'Drink 2 liters for 14 consecutive days', '⚔️', 14, 'streak_days'),
('badge', 'Aqua Champion', 'Drink 2 liters for 30 consecutive days', '🥇', 30, 'streak_days'),
('badge', 'Daily Dynamo', 'Complete 10 daily challenges', '🔥', 10, 'challenges_completed'),
('badge', 'Streak Master', 'Achieve a 50-day hydration streak', '💎', 50, 'streak_days'),
('badge', 'H2O Elite', 'Drink 100 liters total', '🌊', 100000, 'total_ml');

-- Initialize streak tracking
INSERT INTO streak_tracking (current_streak, longest_streak, goal_daily_ml) VALUES (0, 0, 2000);
