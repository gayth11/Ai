
DROP INDEX idx_water_intake_date;
DROP TABLE water_intake;
