import z from "zod";

// Water intake schema and type
export const WaterIntakeSchema = z.object({
  date: z.string(),
  cupsCount: z.number(),
  millilitersPerCup: z.number(),
  totalMilliliters: z.number(),
});

export type WaterIntake = z.infer<typeof WaterIntakeSchema>;

// Achievement schema and type
export const AchievementSchema = z.object({
  id: z.number(),
  type: z.string(),
  name: z.string(),
  description: z.string(),
  icon: z.string(),
  requirementValue: z.number(),
  requirementType: z.string(),
  earnedAt: z.string().nullable(),
  isEarned: z.boolean(),
});

export type Achievement = z.infer<typeof AchievementSchema>;

// Daily challenge schema and type
export const DailyChallengeSchema = z.object({
  id: z.number(),
  date: z.string(),
  challengeType: z.string(),
  challengeText: z.string(),
  targetValue: z.number(),
  currentProgress: z.number(),
  isCompleted: z.boolean(),
  completedAt: z.string().nullable(),
});

export type DailyChallenge = z.infer<typeof DailyChallengeSchema>;

// Streak tracking schema and type
export const StreakTrackingSchema = z.object({
  id: z.number(),
  currentStreak: z.number(),
  longestStreak: z.number(),
  lastGoalDate: z.string().nullable(),
  goalDailyMl: z.number(),
});

export type StreakTracking = z.infer<typeof StreakTrackingSchema>;
