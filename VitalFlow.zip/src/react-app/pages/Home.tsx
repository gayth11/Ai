import { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Coffee, Flame, Droplets, Settings, Plus, Minus, Calendar as CalendarIcon, Trophy, Target, Calculator } from 'lucide-react';
import Calendar from '@/react-app/components/Calendar';
import AchievementCard from '@/react-app/components/AchievementCard';
import StreakCounter from '@/react-app/components/StreakCounter';
import DailyChallenge from '@/react-app/components/DailyChallenge';
import BMICalculator from '@/react-app/components/BMICalculator';
import { useWaterIntake } from '@/react-app/hooks/useWaterIntake';
import { useAchievements } from '@/react-app/hooks/useAchievements';

type TimerMode = 'focus' | 'break';
type ViewMode = 'timer' | 'calendar' | 'achievements' | 'bmi';

export default function Home() {
  const [viewMode, setViewMode] = useState<ViewMode>('timer');
  const [mode, setMode] = useState<TimerMode>('focus');
  const [focusMinutes, setFocusMinutes] = useState(25);
  const [breakMinutes, setBreakMinutes] = useState(5);
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes in seconds
  const [isRunning, setIsRunning] = useState(false);
  const [completedPomodoros, setCompletedPomodoros] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [millilitersPerCup, setMillilitersPerCup] = useState(250);

  // Use the water intake hook
  const { waterCups, toggleWaterCup } = useWaterIntake(millilitersPerCup);
  
  // Use the achievements hook
  const { achievements, streak, dailyChallenge, loading: achievementsLoading, refreshData } = useAchievements();

  // Listen for water intake updates to refresh achievement data
  useEffect(() => {
    const handleWaterIntakeUpdate = () => {
      refreshData();
    };

    window.addEventListener('waterIntakeUpdated', handleWaterIntakeUpdate);
    return () => {
      window.removeEventListener('waterIntakeUpdated', handleWaterIntakeUpdate);
    };
  }, [refreshData]);

  const FOCUS_TIME = focusMinutes * 60;
  const BREAK_TIME = breakMinutes * 60;

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      // Timer completed
      playNotificationSound();
      if (mode === 'focus') {
        setCompletedPomodoros((prev) => prev + 1);
        setMode('break');
        setTimeLeft(BREAK_TIME);
      } else {
        setMode('focus');
        setTimeLeft(FOCUS_TIME);
      }
      setIsRunning(false);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeLeft, mode]);

  const playNotificationSound = () => {
    // Create a simple beep sound using Web Audio API
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  };

  const toggleTimer = () => {
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    if (mode === 'focus') {
      setTimeLeft(FOCUS_TIME);
    } else {
      setTimeLeft(BREAK_TIME);
    }
  };

  const switchMode = (newMode: TimerMode) => {
    setMode(newMode);
    setIsRunning(false);
    setTimeLeft(newMode === 'focus' ? FOCUS_TIME : BREAK_TIME);
  };

  const updateFocusTime = (minutes: number) => {
    const newMinutes = Math.max(1, Math.min(60, minutes));
    setFocusMinutes(newMinutes);
    if (mode === 'focus' && !isRunning) {
      setTimeLeft(newMinutes * 60);
    }
  };

  const updateBreakTime = (minutes: number) => {
    const newMinutes = Math.max(1, Math.min(30, minutes));
    setBreakMinutes(newMinutes);
    if (mode === 'break' && !isRunning) {
      setTimeLeft(newMinutes * 60);
    }
  };

  const updateMillilitersPerCup = (ml: number) => {
    const newMl = Math.max(50, Math.min(1000, ml));
    setMillilitersPerCup(newMl);
  };

  

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = mode === 'focus'
    ? ((FOCUS_TIME - timeLeft) / FOCUS_TIME) * 100
    : ((BREAK_TIME - timeLeft) / BREAK_TIME) * 100;

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-indigo-950 via-purple-900 to-pink-900">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-1/2 -right-1/2 w-full h-full bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-1/2 -left-1/2 w-full h-full bg-gradient-to-tr from-indigo-500/10 to-blue-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-4 mb-4">
            <h1 className="font-display text-5xl md:text-6xl font-bold text-white tracking-tight">
              VitalFlow
            </h1>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  const modes: ViewMode[] = ['timer', 'calendar', 'achievements', 'bmi'];
                  const currentIndex = modes.indexOf(viewMode);
                  const nextIndex = (currentIndex + 1) % modes.length;
                  setViewMode(modes[nextIndex]);
                }}
                className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-95"
                title={
                  viewMode === 'timer' ? 'View Calendar' : 
                  viewMode === 'calendar' ? 'View Achievements' : 
                  viewMode === 'achievements' ? 'View BMI Calculator' : 
                  'View Timer'
                }
              >
                {viewMode === 'timer' && <CalendarIcon className="w-6 h-6 text-white" />}
                {viewMode === 'calendar' && <Trophy className="w-6 h-6 text-white" />}
                {viewMode === 'achievements' && <Calculator className="w-6 h-6 text-white" />}
                {viewMode === 'bmi' && <Target className="w-6 h-6 text-white" />}
              </button>
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-95"
              >
                <Settings className="w-6 h-6 text-white" />
              </button>
            </div>
          </div>
          <p className="text-purple-200 text-lg md:text-xl font-medium">
            {viewMode === 'timer' && 'Boost your health and productivity'}
            {viewMode === 'calendar' && 'Track your hydration journey'}
            {viewMode === 'achievements' && 'Celebrate your progress and achievements'}
            {viewMode === 'bmi' && 'Check if your weight is healthy'}
          </p>
        </div>

        {/* Settings Panel */}
        {showSettings && (
          <div className="w-full max-w-lg mb-6">
            <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 md:p-8 shadow-2xl border border-white/20">
              <h2 className="font-display text-2xl font-bold text-white mb-6 text-center">
                Timer Settings
              </h2>
              
              <div className="space-y-6">
                {/* Focus Time Setting */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Flame className="w-5 h-5 text-orange-400" />
                    <span className="text-white font-medium">Focus Time</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => updateFocusTime(focusMinutes - 1)}
                      className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all duration-200"
                    >
                      <Minus className="w-4 h-4 text-white" />
                    </button>
                    <span className="text-white font-bold text-lg min-w-[3rem] text-center">
                      {focusMinutes}m
                    </span>
                    <button
                      onClick={() => updateFocusTime(focusMinutes + 1)}
                      className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all duration-200"
                    >
                      <Plus className="w-4 h-4 text-white" />
                    </button>
                  </div>
                </div>

                {/* Break Time Setting */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Coffee className="w-5 h-5 text-emerald-400" />
                    <span className="text-white font-medium">Break Time</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => updateBreakTime(breakMinutes - 1)}
                      className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all duration-200"
                    >
                      <Minus className="w-4 h-4 text-white" />
                    </button>
                    <span className="text-white font-bold text-lg min-w-[3rem] text-center">
                      {breakMinutes}m
                    </span>
                    <button
                      onClick={() => updateBreakTime(breakMinutes + 1)}
                      className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all duration-200"
                    >
                      <Plus className="w-4 h-4 text-white" />
                    </button>
                  </div>
                </div>

                {/* Milliliters Per Cup Setting */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Droplets className="w-5 h-5 text-blue-400" />
                    <span className="text-white font-medium">ML per Cup</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => updateMillilitersPerCup(millilitersPerCup - 50)}
                      className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all duration-200"
                    >
                      <Minus className="w-4 h-4 text-white" />
                    </button>
                    <span className="text-white font-bold text-lg min-w-[4rem] text-center">
                      {millilitersPerCup}ml
                    </span>
                    <button
                      onClick={() => updateMillilitersPerCup(millilitersPerCup + 50)}
                      className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all duration-200"
                    >
                      <Plus className="w-4 h-4 text-white" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-white/10 text-center">
                <p className="text-purple-200 text-sm">
                  Focus: 1-60 minutes • Break: 1-30 minutes • Water: 50-1000ml per cup
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Calendar View */}
        {viewMode === 'calendar' && (
          <Calendar millilitersPerCup={millilitersPerCup} />
        )}

        {/* BMI Calculator View */}
        {viewMode === 'bmi' && (
          <BMICalculator />
        )}

        {/* Achievements View */}
        {viewMode === 'achievements' && (
          <div className="w-full max-w-6xl space-y-8">
            {achievementsLoading ? (
              <div className="text-center">
                <div className="animate-spin w-8 h-8 border-2 border-white/30 border-t-white rounded-full mx-auto mb-4"></div>
                <p className="text-white/60">Loading achievements...</p>
              </div>
            ) : (
              <>
                {/* Streak and Daily Challenge Row */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {streak && <StreakCounter streak={streak} />}
                  {dailyChallenge && <DailyChallenge challenge={dailyChallenge} />}
                </div>

                {/* Achievements Grid */}
                <div>
                  <h2 className="font-display text-3xl font-bold text-white text-center mb-8">
                    🏆 Achievements
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {achievements.map((achievement) => (
                      <AchievementCard key={achievement.id} achievement={achievement} />
                    ))}
                  </div>
                  
                  {achievements.length === 0 && (
                    <div className="text-center py-12">
                      <Trophy className="w-16 h-16 text-white/30 mx-auto mb-4" />
                      <p className="text-white/60 text-lg">No achievements yet</p>
                      <p className="text-white/40 text-sm mt-2">Start tracking your water intake to unlock badges!</p>
                    </div>
                  )}
                </div>

                {/* Achievement Stats */}
                <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-white/20">
                  <h3 className="font-display text-xl font-bold text-white text-center mb-6">
                    Achievement Progress
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                    <div>
                      <div className="font-display text-4xl font-bold text-white mb-2">
                        {achievements.filter(a => a.isEarned).length}
                      </div>
                      <div className="text-white/60 text-sm font-medium">Earned</div>
                    </div>
                    <div>
                      <div className="font-display text-4xl font-bold text-white mb-2">
                        {achievements.length - achievements.filter(a => a.isEarned).length}
                      </div>
                      <div className="text-white/60 text-sm font-medium">Remaining</div>
                    </div>
                    <div>
                      <div className="font-display text-4xl font-bold text-white mb-2">
                        {Math.round((achievements.filter(a => a.isEarned).length / Math.max(achievements.length, 1)) * 100)}%
                      </div>
                      <div className="text-white/60 text-sm font-medium">Complete</div>
                    </div>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="mt-6 h-3 bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-500 rounded-full"
                      style={{ width: `${(achievements.filter(a => a.isEarned).length / Math.max(achievements.length, 1)) * 100}%` }}
                    />
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* Timer View */}
        {viewMode === 'timer' && (
          <>
            {/* Main timer card */}
            <div className="w-full max-w-lg">
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20">
            {/* Mode selector */}
            <div className="flex gap-3 mb-8">
              <button
                onClick={() => switchMode('focus')}
                className={`flex-1 py-3 px-6 rounded-2xl font-semibold transition-all duration-300 ${
                  mode === 'focus'
                    ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg shadow-orange-500/50'
                    : 'bg-white/10 text-white/60 hover:bg-white/20'
                }`}
              >
                <Flame className="w-5 h-5 inline-block mr-2" />
                Focus
              </button>
              <button
                onClick={() => switchMode('break')}
                className={`flex-1 py-3 px-6 rounded-2xl font-semibold transition-all duration-300 ${
                  mode === 'break'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg shadow-emerald-500/50'
                    : 'bg-white/10 text-white/60 hover:bg-white/20'
                }`}
              >
                <Coffee className="w-5 h-5 inline-block mr-2" />
                Break
              </button>
            </div>

            {/* Timer display */}
            <div className="relative mb-8">
              {/* Progress ring */}
              <svg className="w-full h-full absolute inset-0" viewBox="0 0 200 200">
                <circle
                  cx="100"
                  cy="100"
                  r="90"
                  fill="none"
                  stroke="rgba(255, 255, 255, 0.1)"
                  strokeWidth="8"
                />
                <circle
                  cx="100"
                  cy="100"
                  r="90"
                  fill="none"
                  stroke={mode === 'focus' ? 'url(#focusGradient)' : 'url(#breakGradient)'}
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 90}`}
                  strokeDashoffset={`${2 * Math.PI * 90 * (1 - progress / 100)}`}
                  transform="rotate(-90 100 100)"
                  className="transition-all duration-1000"
                />
                <defs>
                  <linearGradient id="focusGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#f97316" />
                    <stop offset="100%" stopColor="#ef4444" />
                  </linearGradient>
                  <linearGradient id="breakGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#10b981" />
                    <stop offset="100%" stopColor="#14b8a6" />
                  </linearGradient>
                </defs>
              </svg>
              
              {/* Time text */}
              <div className="relative py-16 text-center">
                <div className="font-display text-7xl md:text-8xl font-bold text-white tracking-tight">
                  {formatTime(timeLeft)}
                </div>
                <div className="mt-2 text-purple-200 text-lg font-medium">
                  {mode === 'focus' ? 'Focus Time' : 'Break Time'}
                </div>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4">
              <button
                onClick={toggleTimer}
                className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg ${
                  mode === 'focus'
                    ? 'bg-gradient-to-br from-orange-500 to-red-500 hover:shadow-orange-500/50'
                    : 'bg-gradient-to-br from-emerald-500 to-teal-500 hover:shadow-emerald-500/50'
                } hover:scale-110 active:scale-95`}
              >
                {isRunning ? (
                  <Pause className="w-8 h-8 text-white" />
                ) : (
                  <Play className="w-8 h-8 text-white ml-1" />
                )}
              </button>
              <button
                onClick={resetTimer}
                className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-95"
              >
                <RotateCcw className="w-6 h-6 text-white" />
              </button>
            </div>

            {/* Stats */}
            <div className="mt-8 pt-8 border-t border-white/10">
              <div className="text-center">
                <div className="text-white/60 text-sm font-medium mb-1">
                  Completed Pomodoros Today
                </div>
                <div className="font-display text-4xl font-bold text-white">
                  {completedPomodoros}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Water Intake Tracker */}
        <div className="mt-8 w-full max-w-lg">
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 md:p-8 shadow-2xl border border-white/20">
            <div className="text-center mb-6">
              <h2 className="font-display text-2xl font-bold text-white mb-2 flex items-center justify-center gap-3">
                <Droplets className="w-6 h-6 text-blue-400" />
                Daily Water Intake
              </h2>
              <p className="text-purple-200 text-sm">
                Tap each cup when you drink water throughout the day ({millilitersPerCup}ml per cup)
              </p>
              
              {/* Current Streak Display */}
              {streak && streak.currentStreak > 0 && (
                <div className="mt-3 flex items-center justify-center gap-2 text-orange-300">
                  <Flame className="w-4 h-4" />
                  <span className="text-sm font-semibold">
                    {streak.currentStreak} day streak!
                  </span>
                </div>
              )}
            </div>
            
            <div className="grid grid-cols-4 gap-4 mb-6">
              {waterCups.map((isFilled, index) => (
                <button
                  key={index}
                  onClick={() => toggleWaterCup(index)}
                  className={`relative w-full aspect-square rounded-2xl border-2 transition-all duration-300 hover:scale-105 active:scale-95 ${
                    isFilled
                      ? 'bg-gradient-to-b from-blue-400 to-blue-600 border-blue-400 shadow-lg shadow-blue-500/50'
                      : 'bg-white/5 border-white/30 hover:bg-white/10'
                  }`}
                >
                  <div className="absolute inset-2 flex items-center justify-center">
                    <div className={`w-8 h-10 rounded-t-full border-2 border-t-0 transition-all duration-300 ${
                      isFilled 
                        ? 'border-white/80 bg-gradient-to-b from-transparent via-blue-200/30 to-blue-300/50' 
                        : 'border-white/30'
                    }`}>
                      {isFilled && (
                        <div className="absolute bottom-0 left-0 right-0 h-3/4 bg-gradient-to-t from-blue-400/60 to-transparent rounded-b-full" />
                      )}
                    </div>
                  </div>
                  <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 text-xs text-white/60 font-medium">
                    {index + 1}
                  </div>
                </button>
              ))}
            </div>
            
            <div className="text-center">
              <div className="text-white/60 text-sm font-medium mb-1">
                Water Intake Today
              </div>
              <div className="font-display text-3xl font-bold text-white">
                {waterCups.filter(cup => cup).length * millilitersPerCup}ml
              </div>
              <div className="text-white/60 text-sm font-medium mb-3">
                {waterCups.filter(cup => cup).length} / 8 cups ({millilitersPerCup}ml each)
              </div>
              <div className="mt-2 h-2 bg-white/10 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-blue-400 to-blue-600 transition-all duration-500 rounded-full"
                  style={{ width: `${(waterCups.filter(cup => cup).length / 8) * 100}%` }}
                />
              </div>
              <div className="mt-2 text-white/40 text-xs">
                Goal: {8 * millilitersPerCup}ml daily
              </div>
            </div>
          </div>
        </div>

        {/* Tips */}
            <div className="mt-8 text-center text-purple-200 text-sm max-w-md">
              <p className="leading-relaxed">
                Work for 25 minutes, then take a 5-minute break. After 4 pomodoros, take a longer 15-30 minute break.
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
