import { useState, useEffect } from 'react';
import type { Achievement, StreakTracking, DailyChallenge } from '@/shared/types';

export function useAchievements() {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [streak, setStreak] = useState<StreakTracking | null>(null);
  const [dailyChallenge, setDailyChallenge] = useState<DailyChallenge | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchAchievements = async () => {
    try {
      const response = await fetch('/api/achievements');
      const data: Achievement[] = await response.json();
      setAchievements(data);
    } catch (error) {
      console.error('Error fetching achievements:', error);
    }
  };

  const fetchStreak = async () => {
    try {
      const response = await fetch('/api/streak');
      const data: StreakTracking = await response.json();
      setStreak(data);
    } catch (error) {
      console.error('Error fetching streak:', error);
    }
  };

  const fetchDailyChallenge = async () => {
    try {
      const response = await fetch('/api/daily-challenge');
      const data: DailyChallenge = await response.json();
      setDailyChallenge(data);
    } catch (error) {
      console.error('Error fetching daily challenge:', error);
    }
  };

  useEffect(() => {
    const fetchAll = async () => {
      setLoading(true);
      await Promise.all([
        fetchAchievements(),
        fetchStreak(),
        fetchDailyChallenge()
      ]);
      setLoading(false);
    };

    fetchAll();
  }, []);

  const refreshData = async () => {
    await Promise.all([
      fetchAchievements(),
      fetchStreak(),
      fetchDailyChallenge()
    ]);
  };

  return {
    achievements,
    streak,
    dailyChallenge,
    loading,
    refreshData
  };
}
