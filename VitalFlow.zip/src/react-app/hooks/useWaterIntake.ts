import { useState, useEffect } from 'react';
import type { WaterIntake } from '@/shared/types';

export function useWaterIntake(millilitersPerCup: number) {
  const [waterCups, setWaterCups] = useState<boolean[]>(new Array(8).fill(false));
  const [loading, setLoading] = useState(true);

  const today = new Date().toISOString().split('T')[0];

  // Load today's water intake on component mount
  useEffect(() => {
    const loadTodaysIntake = async () => {
      try {
        const response = await fetch(`/api/water-intake/${today}`);
        const data: WaterIntake = await response.json();
        
        // Convert cups count back to boolean array
        const newWaterCups = new Array(8).fill(false);
        for (let i = 0; i < Math.min(data.cupsCount, 8); i++) {
          newWaterCups[i] = true;
        }
        setWaterCups(newWaterCups);
      } catch (error) {
        console.error('Error loading water intake:', error);
      } finally {
        setLoading(false);
      }
    };

    loadTodaysIntake();
  }, [today]);

  // Save water intake whenever cups change
  useEffect(() => {
    if (loading) return; // Don't save during initial load

    const saveWaterIntake = async () => {
      const cupsCount = waterCups.filter(cup => cup).length;
      const totalMilliliters = cupsCount * millilitersPerCup;

      const waterIntake: WaterIntake = {
        date: today,
        cupsCount,
        millilitersPerCup,
        totalMilliliters,
      };

      try {
        const response = await fetch('/api/water-intake', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(waterIntake),
        });
        
        if (response.ok) {
          // Trigger a custom event to notify other components about the update
          window.dispatchEvent(new CustomEvent('waterIntakeUpdated'));
        }
      } catch (error) {
        console.error('Error saving water intake:', error);
      }
    };

    saveWaterIntake();
  }, [waterCups, millilitersPerCup, loading, today]);

  const toggleWaterCup = (index: number) => {
    setWaterCups(prev => {
      const newCups = [...prev];
      newCups[index] = !newCups[index];
      return newCups;
    });
  };

  return {
    waterCups,
    toggleWaterCup,
    loading,
  };
}
