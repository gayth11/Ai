import { Flame, TrendingUp } from 'lucide-react';
import type { StreakTracking } from '@/shared/types';

interface StreakCounterProps {
  streak: StreakTracking;
}

export default function StreakCounter({ streak }: StreakCounterProps) {
  const isCurrentStreakActive = () => {
    if (!streak.lastGoalDate) return false;
    
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    return streak.lastGoalDate === today || streak.lastGoalDate === yesterdayStr;
  };

  const streakActive = isCurrentStreakActive();

  return (
    <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-white/20">
      <div className="text-center">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className={`
            w-12 h-12 rounded-full flex items-center justify-center
            ${streakActive 
              ? 'bg-gradient-to-br from-orange-500 to-red-500 shadow-lg shadow-orange-500/50' 
              : 'bg-white/10'
            }
          `}>
            <Flame className={`w-6 h-6 ${streakActive ? 'text-white' : 'text-white/60'}`} />
          </div>
          <h2 className="font-display text-2xl font-bold text-white">
            Current Streak
          </h2>
        </div>
        
        <div className="mb-6">
          <div className="font-display text-6xl font-bold text-white mb-2">
            {streak.currentStreak}
          </div>
          <div className="text-white/60 font-medium">
            {streak.currentStreak === 1 ? 'day' : 'days'} in a row
          </div>
          {!streakActive && streak.currentStreak === 0 && (
            <div className="text-orange-300 text-sm mt-2">
              Start your streak by reaching your daily goal!
            </div>
          )}
        </div>

        <div className="flex items-center justify-center gap-6 pt-6 border-t border-white/10">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <span className="text-white/60 text-sm font-medium">Best Streak</span>
            </div>
            <div className="font-display text-3xl font-bold text-white">
              {streak.longestStreak}
            </div>
            <div className="text-white/40 text-xs">
              {streak.longestStreak === 1 ? 'day' : 'days'}
            </div>
          </div>
          
          <div className="w-px h-12 bg-white/20"></div>
          
          <div className="text-center">
            <div className="text-white/60 text-sm font-medium mb-2">
              Daily Goal
            </div>
            <div className="font-display text-3xl font-bold text-white">
              {streak.goalDailyMl / 1000}L
            </div>
            <div className="text-white/40 text-xs">
              {streak.goalDailyMl}ml
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
