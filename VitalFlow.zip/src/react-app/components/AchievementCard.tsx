import { Trophy, Award, Star } from 'lucide-react';
import type { Achievement } from '@/shared/types';

interface AchievementCardProps {
  achievement: Achievement;
}

export default function AchievementCard({ achievement }: AchievementCardProps) {
  const getIcon = () => {
    switch (achievement.type) {
      case 'badge':
        return <Trophy className="w-8 h-8" />;
      case 'streak':
        return <Award className="w-8 h-8" />;
      default:
        return <Star className="w-8 h-8" />;
    }
  };

  const getEarnedDate = () => {
    if (!achievement.earnedAt) return '';
    return new Date(achievement.earnedAt).toLocaleDateString();
  };

  return (
    <div className={`
      relative p-6 rounded-2xl border-2 transition-all duration-300 hover:scale-105
      ${achievement.isEarned 
        ? 'bg-gradient-to-br from-yellow-400/20 to-orange-500/20 border-yellow-400/50 shadow-lg shadow-yellow-500/25' 
        : 'bg-white/5 border-white/20 hover:bg-white/10'
      }
    `}>
      {/* Achievement Icon */}
      <div className={`
        w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto text-2xl
        ${achievement.isEarned 
          ? 'bg-gradient-to-br from-yellow-400 to-orange-500 text-white shadow-lg' 
          : 'bg-white/10 text-white/60'
        }
      `}>
        {achievement.icon ? (
          <span className="text-2xl">{achievement.icon}</span>
        ) : (
          getIcon()
        )}
      </div>

      {/* Achievement Details */}
      <div className="text-center">
        <h3 className={`
          font-display text-lg font-bold mb-2
          ${achievement.isEarned ? 'text-white' : 'text-white/60'}
        `}>
          {achievement.name}
        </h3>
        
        <p className={`
          text-sm mb-3 leading-relaxed
          ${achievement.isEarned ? 'text-white/80' : 'text-white/50'}
        `}>
          {achievement.description}
        </p>

        {achievement.isEarned && (
          <div className="text-xs text-yellow-300 font-medium">
            Earned {getEarnedDate()}
          </div>
        )}

        {!achievement.isEarned && (
          <div className="text-xs text-white/40">
            {achievement.requirementType === 'streak_days' && 
              `${achievement.requirementValue} day streak required`
            }
            {achievement.requirementType === 'total_ml' && 
              `${achievement.requirementValue / 1000}L total required`
            }
            {achievement.requirementType === 'challenges_completed' && 
              `${achievement.requirementValue} challenges required`
            }
          </div>
        )}
      </div>

      {/* Earned Badge */}
      {achievement.isEarned && (
        <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center shadow-lg">
          <Trophy className="w-4 h-4 text-white" />
        </div>
      )}
    </div>
  );
}
