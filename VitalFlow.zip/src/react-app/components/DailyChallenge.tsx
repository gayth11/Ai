import { Target, CheckCircle, Clock } from 'lucide-react';
import type { DailyChallenge } from '@/shared/types';

interface DailyChallengeProps {
  challenge: DailyChallenge;
}

export default function DailyChallenge({ challenge }: DailyChallengeProps) {
  const progressPercentage = Math.min((challenge.currentProgress / challenge.targetValue) * 100, 100);

  const getChallengeIcon = () => {
    switch (challenge.challengeType) {
      case 'morning_cups':
        return '🌅';
      case 'hourly_sips':
        return '⏰';
      case 'early_start':
        return '🌱';
      case 'afternoon_boost':
        return '🌞';
      case 'evening_hydration':
        return '🌙';
      default:
        return '🎯';
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-white/20">
      <div className="flex items-center gap-4 mb-6">
        <div className={`
          w-14 h-14 rounded-full flex items-center justify-center text-2xl
          ${challenge.isCompleted 
            ? 'bg-gradient-to-br from-green-500 to-emerald-600 shadow-lg shadow-green-500/50' 
            : 'bg-gradient-to-br from-purple-500 to-indigo-600 shadow-lg shadow-purple-500/50'
          }
        `}>
          {challenge.isCompleted ? (
            <CheckCircle className="w-7 h-7 text-white" />
          ) : (
            <span>{getChallengeIcon()}</span>
          )}
        </div>
        
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <Target className="w-5 h-5 text-purple-300" />
            <h3 className="font-display text-lg font-bold text-white">
              Daily Challenge
            </h3>
          </div>
          <p className="text-purple-200 text-sm">
            {challenge.challengeText}
          </p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-white/60 text-sm font-medium">Progress</span>
          <span className="text-white font-bold">
            {challenge.currentProgress} / {challenge.targetValue}
          </span>
        </div>
        
        <div className="h-3 bg-white/10 rounded-full overflow-hidden">
          <div 
            className={`
              h-full transition-all duration-500 rounded-full
              ${challenge.isCompleted 
                ? 'bg-gradient-to-r from-green-400 to-emerald-500' 
                : 'bg-gradient-to-r from-purple-400 to-indigo-500'
              }
            `}
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>

      {/* Status */}
      <div className="text-center">
        {challenge.isCompleted ? (
          <div className="flex items-center justify-center gap-2 text-green-300">
            <CheckCircle className="w-5 h-5" />
            <span className="font-semibold">Challenge Completed!</span>
          </div>
        ) : (
          <div className="flex items-center justify-center gap-2 text-purple-300">
            <Clock className="w-5 h-5" />
            <span className="font-semibold">In Progress</span>
          </div>
        )}
        
        {challenge.isCompleted && challenge.completedAt && (
          <div className="text-white/40 text-xs mt-1">
            Completed {new Date(challenge.completedAt).toLocaleTimeString()}
          </div>
        )}
      </div>
    </div>
  );
}
