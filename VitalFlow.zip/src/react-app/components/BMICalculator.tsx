import { useState } from 'react';
import { Calculator, CheckCircle, AlertTriangle, Activity, Info } from 'lucide-react';

export default function BMICalculator() {
  const [height, setHeight] = useState<string>('');
  const [weight, setWeight] = useState<string>('');
  const [result, setResult] = useState<{
    bmi: number;
    category: string;
    isNormal: boolean;
  } | null>(null);

  const calculateBMI = () => {
    const heightNum = parseFloat(height);
    const weightNum = parseFloat(weight);

    if (!heightNum || !weightNum || heightNum <= 0 || weightNum <= 0) {
      return;
    }

    // Convert height from cm to meters
    const heightM = heightNum / 100;
    const bmi = weightNum / (heightM * heightM);
    
    let category = '';
    let isNormal = false;

    if (bmi < 18.5) {
      category = 'Underweight';
      isNormal = false;
    } else if (bmi >= 18.5 && bmi < 25) {
      category = 'Normal weight';
      isNormal = true;
    } else if (bmi >= 25 && bmi < 30) {
      category = 'Overweight';
      isNormal = false;
    } else {
      category = 'Obese';
      isNormal = false;
    }

    setResult({
      bmi: Math.round(bmi * 10) / 10,
      category,
      isNormal
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    calculateBMI();
  };

  const resetCalculator = () => {
    setHeight('');
    setWeight('');
    setResult(null);
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-lg shadow-green-500/30">
              <Calculator className="w-6 h-6 text-white" />
            </div>
            <h2 className="font-display text-3xl md:text-4xl font-bold text-white">
              BMI Calculator
            </h2>
          </div>
          <p className="text-purple-200 text-lg font-medium leading-relaxed">
            Check if Your Weight is Healthy
          </p>
          <div className="mt-4 p-4 bg-white/5 rounded-2xl border border-white/10">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-blue-300 mt-0.5 flex-shrink-0" />
              <p className="text-white/80 text-sm leading-relaxed text-left">
                Enter your height and weight to see if your weight is within the healthy range. 
                Our calculator uses the Body Mass Index (BMI) to determine if your weight is normal or not.
              </p>
            </div>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6 mb-8">
          {/* Height Input */}
          <div>
            <label htmlFor="height" className="block text-white font-semibold mb-3 text-lg">
              Height (cm)
            </label>
            <div className="relative">
              <input
                type="number"
                id="height"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                placeholder="Enter your height in centimeters"
                className="w-full px-6 py-4 bg-white/10 border border-white/20 rounded-2xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300 text-lg backdrop-blur-sm"
                step="0.1"
                min="50"
                max="300"
              />
              <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white/60 font-medium">
                cm
              </div>
            </div>
          </div>

          {/* Weight Input */}
          <div>
            <label htmlFor="weight" className="block text-white font-semibold mb-3 text-lg">
              Weight (kg)
            </label>
            <div className="relative">
              <input
                type="number"
                id="weight"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder="Enter your weight in kilograms"
                className="w-full px-6 py-4 bg-white/10 border border-white/20 rounded-2xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300 text-lg backdrop-blur-sm"
                step="0.1"
                min="20"
                max="500"
              />
              <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white/60 font-medium">
                kg
              </div>
            </div>
          </div>

          {/* Calculate Button */}
          <button
            type="submit"
            disabled={!height || !weight}
            className="w-full py-4 px-8 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:from-gray-500 disabled:to-gray-600 disabled:cursor-not-allowed text-white font-bold text-lg rounded-2xl transition-all duration-300 shadow-lg hover:shadow-green-500/30 hover:scale-[1.02] active:scale-98 disabled:hover:scale-100"
          >
            <div className="flex items-center justify-center gap-3">
              <Activity className="w-6 h-6" />
              Check
            </div>
          </button>
        </form>

        {/* Results */}
        {result && (
          <div className="space-y-6">
            {/* BMI Value */}
            <div className="text-center p-6 bg-white/5 rounded-2xl border border-white/10">
              <div className="text-white/60 text-sm font-medium mb-2">Your BMI</div>
              <div className="font-display text-5xl font-bold text-white mb-2">
                {result.bmi}
              </div>
              <div className="text-white/80 text-lg font-medium">
                {result.category}
              </div>
            </div>

            {/* Result Message */}
            <div className={`p-6 rounded-2xl border-2 ${
              result.isNormal 
                ? 'bg-green-500/10 border-green-500/30 backdrop-blur-sm'
                : 'bg-orange-500/10 border-orange-500/30 backdrop-blur-sm'
            }`}>
              <div className="flex items-center gap-4">
                {result.isNormal ? (
                  <CheckCircle className="w-8 h-8 text-green-400 flex-shrink-0" />
                ) : (
                  <AlertTriangle className="w-8 h-8 text-orange-400 flex-shrink-0" />
                )}
                <div>
                  <div className={`font-bold text-xl ${
                    result.isNormal ? 'text-green-300' : 'text-orange-300'
                  }`}>
                    {result.isNormal ? '✅ Your weight is normal.' : '⚠️ Your weight is not normal.'}
                  </div>
                  <div className="text-white/80 text-sm mt-2">
                    {result.isNormal 
                      ? 'Great job! You are within the healthy weight range.'
                      : 'Consider consulting with a healthcare professional for personalized advice.'
                    }
                  </div>
                </div>
              </div>
            </div>

            {/* BMI Categories Reference */}
            <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
              <h3 className="text-white font-bold text-lg mb-4 text-center">BMI Categories</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div className="flex justify-between items-center p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
                  <span className="text-white/80">Underweight</span>
                  <span className="text-blue-300 font-medium">&lt; 18.5</span>
                </div>
                <div className="flex justify-between items-center p-3 rounded-xl bg-green-500/10 border border-green-500/20">
                  <span className="text-white/80">Normal weight</span>
                  <span className="text-green-300 font-medium">18.5 - 24.9</span>
                </div>
                <div className="flex justify-between items-center p-3 rounded-xl bg-orange-500/10 border border-orange-500/20">
                  <span className="text-white/80">Overweight</span>
                  <span className="text-orange-300 font-medium">25 - 29.9</span>
                </div>
                <div className="flex justify-between items-center p-3 rounded-xl bg-red-500/10 border border-red-500/20">
                  <span className="text-white/80">Obese</span>
                  <span className="text-red-300 font-medium">≥ 30</span>
                </div>
              </div>
            </div>

            {/* Reset Button */}
            <button
              onClick={resetCalculator}
              className="w-full py-3 px-6 bg-white/10 hover:bg-white/20 text-white font-medium rounded-2xl transition-all duration-300 border border-white/20"
            >
              Calculate Again
            </button>
          </div>
        )}

        {/* Disclaimer */}
        <div className="mt-8 p-4 bg-white/5 rounded-2xl border border-white/10">
          <p className="text-white/60 text-xs text-center leading-relaxed">
            <strong>Disclaimer:</strong> BMI is a screening tool and not a diagnostic tool. 
            This calculator is for informational purposes only and should not replace professional medical advice.
          </p>
        </div>
      </div>
    </div>
  );
}
