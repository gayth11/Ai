import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Droplets } from 'lucide-react';
import type { WaterIntake } from '@/shared/types';

interface CalendarProps {
  millilitersPerCup: number;
}

export default function Calendar({ millilitersPerCup }: CalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [waterData, setWaterData] = useState<Record<string, WaterIntake>>({});
  const [loading, setLoading] = useState(true);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  // Get first day of month and number of days
  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const startCalendar = new Date(firstDayOfMonth);
  startCalendar.setDate(startCalendar.getDate() - firstDayOfMonth.getDay());
  
  const endCalendar = new Date(lastDayOfMonth);
  endCalendar.setDate(endCalendar.getDate() + (6 - lastDayOfMonth.getDay()));

  // Fetch water data for the current month
  useEffect(() => {
    const fetchWaterData = async () => {
      setLoading(true);
      try {
        const startDate = startCalendar.toISOString().split('T')[0];
        const endDate = endCalendar.toISOString().split('T')[0];
        
        const response = await fetch(`/api/water-intake?startDate=${startDate}&endDate=${endDate}`);
        const data: WaterIntake[] = await response.json();
        
        const dataMap: Record<string, WaterIntake> = {};
        data.forEach(item => {
          dataMap[item.date] = item;
        });
        
        setWaterData(dataMap);
      } catch (error) {
        console.error('Error fetching water data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchWaterData();
  }, [currentDate]);

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      newDate.setMonth(prev.getMonth() + (direction === 'next' ? 1 : -1));
      return newDate;
    });
  };

  const generateCalendarDays = () => {
    const days = [];
    const current = new Date(startCalendar);
    
    while (current <= endCalendar) {
      days.push(new Date(current));
      current.setDate(current.getDate() + 1);
    }
    
    return days;
  };

  const formatDateKey = (date: Date) => {
    return date.toISOString().split('T')[0];
  };

  const isCurrentMonth = (date: Date) => {
    return date.getMonth() === month;
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  const getWaterIntakeForDate = (date: Date) => {
    const dateKey = formatDateKey(date);
    return waterData[dateKey] || { cupsCount: 0, totalMilliliters: 0 };
  };

  const getHydrationLevel = (cups: number) => {
    if (cups === 0) return 'none';
    if (cups < 3) return 'low';
    if (cups < 6) return 'medium';
    if (cups < 8) return 'good';
    return 'excellent';
  };

  const getHydrationColor = (level: string) => {
    switch (level) {
      case 'none': return 'bg-gray-500/20';
      case 'low': return 'bg-red-500/40';
      case 'medium': return 'bg-yellow-500/40';
      case 'good': return 'bg-blue-500/40';
      case 'excellent': return 'bg-emerald-500/40';
      default: return 'bg-gray-500/20';
    }
  };

  const days = generateCalendarDays();
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  if (loading) {
    return (
      <div className="w-full max-w-4xl">
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/20">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-2 border-white/30 border-t-white rounded-full mx-auto mb-4"></div>
            <p className="text-white/60">Loading calendar...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl">
      <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 md:p-8 shadow-2xl border border-white/20">
        {/* Calendar Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => navigateMonth('prev')}
            className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-95"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          
          <div className="text-center">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-white">
              {monthNames[month]} {year}
            </h2>
            <p className="text-purple-200 text-sm mt-1">
              Daily water intake tracking
            </p>
          </div>
          
          <button
            onClick={() => navigateMonth('next')}
            className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-95"
          >
            <ChevronRight className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Day Headers */}
        <div className="grid grid-cols-7 gap-2 mb-4">
          {dayNames.map(day => (
            <div key={day} className="text-center py-3">
              <span className="text-white/60 font-medium text-sm">{day}</span>
            </div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-2 mb-8">
          {days.map(date => {
            const dateKey = formatDateKey(date);
            const waterIntake = getWaterIntakeForDate(date);
            const hydrationLevel = getHydrationLevel(waterIntake.cupsCount);
            const isCurrentMonthDate = isCurrentMonth(date);
            const isTodayDate = isToday(date);
            
            return (
              <div
                key={dateKey}
                className={`
                  relative aspect-square rounded-xl p-2 transition-all duration-300
                  ${isCurrentMonthDate ? 'bg-white/5' : 'bg-white/2'}
                  ${isTodayDate ? 'ring-2 ring-blue-400' : ''}
                  hover:bg-white/10
                `}
              >
                <div className="h-full flex flex-col">
                  <div className={`text-sm font-medium mb-1 ${
                    isCurrentMonthDate ? 'text-white' : 'text-white/40'
                  }`}>
                    {date.getDate()}
                  </div>
                  
                  {isCurrentMonthDate && waterIntake.cupsCount > 0 && (
                    <div className="flex-1 flex flex-col justify-center items-center">
                      <div className={`
                        w-8 h-8 rounded-full flex items-center justify-center mb-1
                        ${getHydrationColor(hydrationLevel)}
                      `}>
                        <Droplets className="w-4 h-4 text-white" />
                      </div>
                      <div className="text-xs text-white/80 font-medium">
                        {waterIntake.cupsCount}c
                      </div>
                      <div className="text-xs text-white/60">
                        {waterIntake.totalMilliliters}ml
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="border-t border-white/10 pt-6">
          <h3 className="font-display text-lg font-bold text-white mb-4 text-center">
            Hydration Levels
          </h3>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-gray-500/20"></div>
              <span className="text-white/60">No data</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-red-500/40"></div>
              <span className="text-white/60">Low (1-2 cups)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-yellow-500/40"></div>
              <span className="text-white/60">Medium (3-5 cups)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-blue-500/40"></div>
              <span className="text-white/60">Good (6-7 cups)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-emerald-500/40"></div>
              <span className="text-white/60">Excellent (8+ cups)</span>
            </div>
          </div>
          <p className="text-center text-white/40 text-xs mt-4">
            Based on {millilitersPerCup}ml per cup
          </p>
        </div>
      </div>
    </div>
  );
}
