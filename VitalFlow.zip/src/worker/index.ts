import { Hono } from "hono";
import { cors } from "hono/cors";
import { z } from "zod";

const app = new Hono<{ Bindings: Env }>();

// Enable CORS for all routes
app.use('/*', cors());

// Schema for water intake data
const WaterIntakeSchema = z.object({
  date: z.string(),
  cupsCount: z.number(),
  millilitersPerCup: z.number(),
  totalMilliliters: z.number(),
});

// Helper function to generate daily challenge
function generateDailyChallenge(date: string) {
  const challenges = [
    { type: 'morning_cups', text: 'Drink 3 cups before noon!', target: 3 },
    { type: 'hourly_sips', text: 'Take a sip every hour for 8 hours', target: 8 },
    { type: 'early_start', text: 'Drink your first cup within 1 hour of waking', target: 1 },
    { type: 'afternoon_boost', text: 'Drink 2 cups between 2-4 PM', target: 2 },
    { type: 'evening_hydration', text: 'Drink 4 cups by 6 PM', target: 4 },
  ];
  
  // Use date as seed for consistent daily challenges
  const dateNum = new Date(date).getTime();
  const challengeIndex = Math.floor(dateNum / (1000 * 60 * 60 * 24)) % challenges.length;
  
  return challenges[challengeIndex];
}

// Helper function to update streaks and check achievements
async function updateStreaksAndAchievements(c: any, date: string, totalMilliliters: number) {
  const goalDailyMl = 2000; // 2 liters default goal
  
  try {
    // Get current streak data
    const streakData = await c.env.DB.prepare(
      'SELECT * FROM streak_tracking ORDER BY id DESC LIMIT 1'
    ).first();
    
    let currentStreak = streakData?.current_streak || 0;
    let longestStreak = streakData?.longest_streak || 0;
    let lastGoalDate = streakData?.last_goal_date;
    
    // Check if goal was met today
    const goalMet = totalMilliliters >= goalDailyMl;
    const today = new Date(date);
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    if (goalMet) {
      // Goal met today
      if (lastGoalDate === yesterdayStr) {
        // Continuing streak
        currentStreak += 1;
      } else if (lastGoalDate !== date) {
        // Starting new streak
        currentStreak = 1;
      }
      
      if (currentStreak > longestStreak) {
        longestStreak = currentStreak;
      }
      
      lastGoalDate = date;
    } else {
      // Goal not met - check if streak should be broken
      if (lastGoalDate === yesterdayStr && lastGoalDate !== date) {
        // Streak was active yesterday but goal not met today
        currentStreak = 0;
      }
    }
    
    // Update streak tracking
    await c.env.DB.prepare(
      `INSERT OR REPLACE INTO streak_tracking 
       (id, current_streak, longest_streak, last_goal_date, goal_daily_ml, updated_at) 
       VALUES (1, ?, ?, ?, ?, CURRENT_TIMESTAMP)`
    ).bind(currentStreak, longestStreak, lastGoalDate, goalDailyMl).run();
    
    // Check and update achievements
    if (goalMet) {
      const achievements = await c.env.DB.prepare(
        'SELECT * FROM achievements WHERE requirement_type = "streak_days" AND is_earned = FALSE'
      ).all();
      
      for (const achievement of achievements.results) {
        if (currentStreak >= achievement.requirement_value) {
          await c.env.DB.prepare(
            'UPDATE achievements SET is_earned = TRUE, earned_at = CURRENT_TIMESTAMP WHERE id = ?'
          ).bind(achievement.id).run();
        }
      }
    }
    
  } catch (error) {
    console.error('Error updating streaks and achievements:', error);
  }
}

// Get water intake for a specific date
app.get('/api/water-intake/:date', async (c) => {
  const date = c.req.param('date');
  
  try {
    const result = await c.env.DB.prepare(
      'SELECT * FROM water_intake WHERE date = ?'
    ).bind(date).first();
    
    if (!result) {
      return c.json({
        date,
        cupsCount: 0,
        millilitersPerCup: 250,
        totalMilliliters: 0
      });
    }
    
    return c.json({
      date: result.date,
      cupsCount: result.cups_count,
      millilitersPerCup: result.milliliters_per_cup,
      totalMilliliters: result.total_milliliters
    });
  } catch (error) {
    console.error('Error fetching water intake:', error);
    return c.json({ error: 'Failed to fetch water intake' }, 500);
  }
});

// Get water intake for a date range (for calendar view)
app.get('/api/water-intake', async (c) => {
  const startDate = c.req.query('startDate');
  const endDate = c.req.query('endDate');
  
  if (!startDate || !endDate) {
    return c.json({ error: 'startDate and endDate are required' }, 400);
  }
  
  try {
    const results = await c.env.DB.prepare(
      'SELECT * FROM water_intake WHERE date >= ? AND date <= ? ORDER BY date'
    ).bind(startDate, endDate).all();
    
    const waterIntake = results.results.map((row: any) => ({
      date: row.date,
      cupsCount: row.cups_count,
      millilitersPerCup: row.milliliters_per_cup,
      totalMilliliters: row.total_milliliters
    }));
    
    return c.json(waterIntake);
  } catch (error) {
    console.error('Error fetching water intake range:', error);
    return c.json({ error: 'Failed to fetch water intake' }, 500);
  }
});

// Save or update water intake for a specific date
app.post('/api/water-intake', async (c) => {
  try {
    const body = await c.req.json();
    const validatedData = WaterIntakeSchema.parse(body);
    
    const { date, cupsCount, millilitersPerCup, totalMilliliters } = validatedData;
    
    // Use INSERT OR REPLACE to handle both create and update
    await c.env.DB.prepare(
      `INSERT OR REPLACE INTO water_intake 
       (date, cups_count, milliliters_per_cup, total_milliliters, updated_at) 
       VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)`
    ).bind(date, cupsCount, millilitersPerCup, totalMilliliters).run();
    
    // Update streaks and check achievements
    await updateStreaksAndAchievements(c, date, totalMilliliters);
    
    // Update daily challenge progress
    await updateDailyChallengeProgress(c, date, cupsCount, totalMilliliters);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error saving water intake:', error);
    return c.json({ error: 'Failed to save water intake' }, 500);
  }
});

// Helper function to update daily challenge progress
async function updateDailyChallengeProgress(c: any, date: string, cupsCount: number, _totalMilliliters: number) {
  try {
    // Get today's challenge
    let challenge = await c.env.DB.prepare(
      'SELECT * FROM daily_challenges WHERE date = ?'
    ).bind(date).first();
    
    // Create challenge if it doesn't exist
    if (!challenge) {
      const dailyChallenge = generateDailyChallenge(date);
      await c.env.DB.prepare(
        `INSERT INTO daily_challenges 
         (date, challenge_type, challenge_text, target_value, current_progress) 
         VALUES (?, ?, ?, ?, 0)`
      ).bind(date, dailyChallenge.type, dailyChallenge.text, dailyChallenge.target).run();
      
      challenge = await c.env.DB.prepare(
        'SELECT * FROM daily_challenges WHERE date = ?'
      ).bind(date).first();
    }
    
    if (!challenge) return;
    
    let progress = 0;
    let isCompleted = false;
    
    // Calculate progress based on challenge type
    switch (challenge.challenge_type) {
      case 'morning_cups':
      case 'afternoon_boost':
      case 'evening_hydration':
        // For now, use total cups as progress (could be enhanced with time tracking)
        progress = cupsCount;
        break;
      case 'early_start':
        progress = cupsCount > 0 ? 1 : 0;
        break;
      case 'hourly_sips':
        // Simplified - consider each cup as an hour
        progress = Math.min(cupsCount, challenge.target_value);
        break;
    }
    
    isCompleted = progress >= challenge.target_value;
    
    // Update challenge progress
    await c.env.DB.prepare(
      `UPDATE daily_challenges 
       SET current_progress = ?, is_completed = ?, 
           completed_at = CASE WHEN ? THEN CURRENT_TIMESTAMP ELSE completed_at END,
           updated_at = CURRENT_TIMESTAMP
       WHERE date = ?`
    ).bind(progress, isCompleted, isCompleted, date).run();
    
  } catch (error) {
    console.error('Error updating daily challenge:', error);
  }
}

// Get achievements
app.get('/api/achievements', async (c) => {
  try {
    const results = await c.env.DB.prepare(
      'SELECT * FROM achievements ORDER BY earned_at DESC, requirement_value ASC'
    ).all();
    
    const achievements = results.results.map((row: any) => ({
      id: row.id,
      type: row.type,
      name: row.name,
      description: row.description,
      icon: row.icon,
      requirementValue: row.requirement_value,
      requirementType: row.requirement_type,
      earnedAt: row.earned_at,
      isEarned: row.is_earned
    }));
    
    return c.json(achievements);
  } catch (error) {
    console.error('Error fetching achievements:', error);
    return c.json({ error: 'Failed to fetch achievements' }, 500);
  }
});

// Get streak information
app.get('/api/streak', async (c) => {
  try {
    const result = await c.env.DB.prepare(
      'SELECT * FROM streak_tracking ORDER BY id DESC LIMIT 1'
    ).first();
    
    if (!result) {
      return c.json({
        id: 1,
        currentStreak: 0,
        longestStreak: 0,
        lastGoalDate: null,
        goalDailyMl: 2000
      });
    }
    
    return c.json({
      id: result.id,
      currentStreak: result.current_streak,
      longestStreak: result.longest_streak,
      lastGoalDate: result.last_goal_date,
      goalDailyMl: result.goal_daily_ml
    });
  } catch (error) {
    console.error('Error fetching streak:', error);
    return c.json({ error: 'Failed to fetch streak' }, 500);
  }
});

// Get today's daily challenge
app.get('/api/daily-challenge', async (c) => {
  const today = new Date().toISOString().split('T')[0];
  
  try {
    let challenge = await c.env.DB.prepare(
      'SELECT * FROM daily_challenges WHERE date = ?'
    ).bind(today).first();
    
    // Create challenge if it doesn't exist
    if (!challenge) {
      const dailyChallenge = generateDailyChallenge(today);
      await c.env.DB.prepare(
        `INSERT INTO daily_challenges 
         (date, challenge_type, challenge_text, target_value, current_progress) 
         VALUES (?, ?, ?, ?, 0)`
      ).bind(today, dailyChallenge.type, dailyChallenge.text, dailyChallenge.target).run();
      
      challenge = await c.env.DB.prepare(
        'SELECT * FROM daily_challenges WHERE date = ?'
      ).bind(today).first();
    }
    
    if (!challenge) {
      return c.json({ error: 'Failed to create daily challenge' }, 500);
    }

    return c.json({
      id: challenge.id,
      date: challenge.date,
      challengeType: challenge.challenge_type,
      challengeText: challenge.challenge_text,
      targetValue: challenge.target_value,
      currentProgress: challenge.current_progress,
      isCompleted: challenge.is_completed,
      completedAt: challenge.completed_at
    });
  } catch (error) {
    console.error('Error fetching daily challenge:', error);
    return c.json({ error: 'Failed to fetch daily challenge' }, 500);
  }
});

export default app;
